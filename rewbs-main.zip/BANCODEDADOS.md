# Banco de Dados
As únicas informações salvas no banco de dados deve ser o objeto do user, como exemplificado no [Rewbs Readme](https://github.com/WilckerK/rewbs/blob/main/README.md#objeto-do-user), as raças dos bews e as cartas.
As informações dos bews devem ser retiradas do próprio id dele.

# =-=-=-=-=-=-=-=-= CONSTRUÇÃO =-=-=-=-=-=-=-=-=
