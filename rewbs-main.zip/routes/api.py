from __main__ import app, db, bew, secret_key
from flask import jsonify, request

@app.route('/api/summon_bew', methods=['GET']) # GET -> Pegar valor
def summon_bew():
	response = bew.summon_bew()
	return jsonify(response) # Transforma em JSON


# curl -X POST -H "Content-Type: application/json" -d '{"userId": "6403ac5003f8e40841a1b105", "bewId": "CUR001F03G2ETFER3000002011502"}' http://localhost:5000/api/query_bew
# curl -X POST -H "Content-Type: application/json" -d '{"userId": "6403aca303f8e40841a1b106", "bewId": "SANTOCRISTO"}' http://localhost:5000/api/query_bew
@app.route('/api/query_bew', methods=['POST']) # POST -> Passar valor
def query_bew():
	data = request.json # Get request


	# Check if have necessary values
	if(sorted(list(data.keys())) != ['bewId', 'userId']):
		return jsonify({ "status": 'Invalid Fields' })

	response = bew.query_bew(data, db) # Get response
	return jsonify(response)


# curl -X POST -H "Content-Type: application/json" -d '{"message": "ola"}' http://localhost:5000/api/echo
# curl -X POST -H "Content-Type: application/json" -d '{"userId": "6403ac5003f8e40841a1b105", "userId2": "6403aca303f8e40841a1b106", "bewId": "CUR001F03G2ETFER3000002011502", "bewId2": "SANTOCRISTO", "secret_key": "CHAVESUPERSECRETA321123"}' http://localhost:5000/api/trade
@app.route('/api/trade_bews', methods=['POST']) # POST -> Passar valor
def trade_bews():
	data = request.json # Get request

	# Check if have necessary values
	if(sorted(list(data.keys())) != ['bewId', 'bewId2', 'secret_key', 'userId', 'userId2']):
		return jsonify({ "status": 'Invalid Fields' })

	# Check for secret_key
	if data['secret_key'] != secret_key:
		return jsonify({ "status": 'Invalid Key' })

	response = bew.trade_bews(data, db) # Get response
	return jsonify(response)


